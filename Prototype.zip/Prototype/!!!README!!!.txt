To open the prototype:
1. extract the prototype folder
2. open the homepage.html file

Do not move anything!